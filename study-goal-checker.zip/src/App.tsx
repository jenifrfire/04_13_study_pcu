import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight,
  BookOpen,
  Target
} from 'lucide-react';
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  isSameMonth, 
  isSameDay, 
  eachDayOfInterval,
  parseISO
} from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Goal {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string; // ISO string
}

export default function App() {
  const [goals, setGoals] = useState<Goal[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem('study_goals');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [inputText, setInputText] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    localStorage.setItem('study_goals', JSON.stringify(goals));
  }, [goals]);

  const addGoal = () => {
    if (!inputText.trim()) return;
    const newGoal: Goal = {
      id: crypto.randomUUID(),
      text: inputText.trim(),
      completed: false,
      createdAt: new Date().toISOString(),
    };
    setGoals([newGoal, ...goals]);
    setInputText('');
  };

  const toggleGoal = (id: string) => {
    setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  const deleteGoal = (id: string) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  const goalsByDate = useMemo(() => {
    const map: Record<string, number> = {};
    goals.forEach(g => {
      const dateStr = format(parseISO(g.createdAt), 'yyyy-MM-dd');
      map[dateStr] = (map[dateStr] || 0) + 1;
    });
    return map;
  }, [goals]);

  const successRate = goals.length > 0 ? Math.round((goals.filter(g => g.completed).length / goals.length) * 100) : 0;

  return (
    <div className="max-w-[1024px] mx-auto px-6 py-8 h-full flex flex-col gap-6" id="app-container">
      {/* Header */}
      <header className="flex justify-between items-end px-2" id="header">
        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
            Study Goal <span className="text-indigo-600">Checker</span>
          </h1>
          <p className="text-slate-500 font-medium uppercase tracking-widest text-[10px]">
            Optimize your learning journey
          </p>
        </div>
        <div className="text-right">
          <div className="text-lg font-semibold text-slate-700">
            {format(currentDate, 'MMMM yyyy')}
          </div>
          <div className="text-sm text-slate-400">
            {goals.filter(g => !g.completed).length} goals pending
          </div>
        </div>
      </header>

      <main className="grid grid-cols-12 gap-6 flex-grow" id="main-content">
        {/* Left Column (Calendar + Stats) */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-6">
          <div className="bento-card flex-grow" id="calendar-card">
            <Calendar 
              currentDate={currentDate} 
              setCurrentDate={setCurrentDate}
              goalsByDate={goalsByDate}
            />
            <div className="mt-6 pt-6 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-indigo-600"></div>
                <span className="text-xs font-medium text-slate-600">Active Goals Recorded</span>
              </div>
            </div>
          </div>

          <div className="bento-card h-40 bg-indigo-600 text-white border-none flex flex-col justify-between" id="stats-card">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium opacity-80 flex items-center gap-2">
                <Target size={14} />
                Success Rate
              </div>
              <div className="bg-indigo-500/30 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
                Overall
              </div>
            </div>
            <div className="text-4xl font-bold">{successRate}%</div>
            <div className="w-full bg-indigo-500 rounded-full h-1.5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${successRate}%` }}
                className="bg-white h-1.5 rounded-full"
              />
            </div>
          </div>
        </div>

        {/* Right Column (Input + Goals List) */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-6">
          {/* Input Box */}
          <div className="bento-card" id="input-section">
            <div className="flex gap-3">
              <input
                id="goal-input"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addGoal()}
                placeholder="What do you want to learn today?"
                className="flex-grow bg-slate-50 border-none rounded-xl px-4 py-3 text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <button
                id="add-goal-btn"
                onClick={addGoal}
                disabled={!inputText.trim()}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Goal
              </button>
            </div>
          </div>

          {/* List Box */}
          <div className="bento-card flex-grow flex flex-col overflow-hidden" id="goals-list-container">
            <h3 className="font-bold text-slate-800 text-lg mb-4">Active Goals</h3>
            <div 
              id="goals-list" 
              className="space-y-3 overflow-y-auto custom-scroll pr-2 max-h-[420px]"
            >
              <AnimatePresence mode="popLayout" initial={false}>
                {goals.length === 0 ? (
                  <motion.div 
                    key="empty"
                    id="empty-state"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="py-12 text-center text-slate-400 flex flex-col items-center gap-3"
                  >
                    <BookOpen size={40} className="opacity-20" />
                    <p className="font-medium">Your study journey starts here.</p>
                  </motion.div>
                ) : (
                  goals.map((goal) => (
                    <motion.div
                      key={goal.id}
                      id={`goal-${goal.id}`}
                      layout
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, x: -10 }}
                      className={cn(
                        "group flex items-center justify-between p-4 rounded-2xl border transition-all",
                        goal.completed 
                          ? "bg-slate-50 border-transparent opacity-60" 
                          : "bg-white border-slate-100 shadow-sm"
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => toggleGoal(goal.id)}
                          className={cn(
                            "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all",
                            goal.completed 
                              ? "bg-emerald-500 border-emerald-500" 
                              : "border-slate-200 group-hover:border-indigo-400"
                          )}
                        >
                          <CheckCircle2 size={14} className={cn("text-white", goal.completed ? "block" : "hidden")} />
                        </button>
                        <span className={cn(
                          "font-medium transition-all",
                          goal.completed ? "line-through text-slate-400" : "text-slate-700"
                        )}>
                          {goal.text}
                        </span>
                      </div>

                      <button
                        onClick={() => deleteGoal(goal.id)}
                        className="p-2 text-slate-300 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 size={18} />
                      </button>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function Calendar({ currentDate, setCurrentDate, goalsByDate }: { 
  currentDate: Date, 
  setCurrentDate: (d: Date) => void,
  goalsByDate: Record<string, number>
}) {
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);

  const days = eachDayOfInterval({ start: startDate, end: endDate });

  return (
    <div className="select-none" id="calendar-widget">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-bold text-slate-800 text-lg">Calendar</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}
            className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <button 
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}
            className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map(day => (
          <div key={day} className="text-center text-[10px] font-bold text-slate-400 uppercase">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {days.map((day, idx) => {
          const dateStr = format(day, 'yyyy-MM-dd');
          const hasGoals = !!goalsByDate[dateStr];
          const isInMonth = isSameMonth(day, monthStart);
          const isToday = isSameDay(day, new Date());

          return (
            <div 
              key={idx}
              className={cn(
                "aspect-square flex items-center justify-center text-xs rounded-lg transition-colors",
                !isInMonth && "opacity-20",
                isToday ? "bg-indigo-600 text-white font-bold" : "text-slate-600",
                hasGoals && !isToday && "bg-indigo-50 border border-indigo-100 text-indigo-700"
              )}
            >
              <span>{format(day, 'd')}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
